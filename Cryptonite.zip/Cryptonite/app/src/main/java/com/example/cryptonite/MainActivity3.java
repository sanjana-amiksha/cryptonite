package com.example.cryptonite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    EditText text, keyword;
    TextView output;
    Button encrypt, decrypt;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

    }

    public void exit(View v) {
        System.exit(0);
    }
    public void encryption(View v) {
        String plainText = "", cypherText = "Cipher Text: ", key = "";  //variables

        text = findViewById(R.id.text);
        keyword = findViewById(R.id.keyword);
        output=findViewById(R.id.output);
        DB=new DBHelper(this);
        plainText = text.getText().toString();
        plainText = plainText.replaceAll("\\s", "").toUpperCase();
        key = keyword.getText().toString();
        key = key.replaceAll("\\s", "").toUpperCase();     //remove all spaces and convert the keyword to uppercase (as given in example)


        if (plainText.isEmpty() || key.isEmpty()) {
            Toast.makeText(MainActivity3.this,"Fill text boxes",Toast.LENGTH_SHORT).show();
        } else {
            for (int i = 0; i < plainText.length(); i++) {   //if take one character from the plain text till it's end
                char ch = plainText.charAt(i);
                char k = key.charAt(i % key.length());   //This takes each character of keyword and starts from beginning if keyword ends
                int index = (int) ch - 65;                //We use letter index instead of ASCII value (A is 0 instead of 65 and so on )
                k += index;                            //We shift the keyword letter with index. This is beacause, in our table, the row shifts as our index increase.(A=A as A=0, A=B as row B=1)
                if (k > 90) {                            //If we go beyond 90 ("Z"); we will subtract 26 to start again from "A"
                    k -= 26;
                    cypherText += k;                   //Add to cyphertext
                } else {
                    cypherText += k;                   //Add to cyphertext
                }

            }
            output.setText(cypherText);

            String textTXT = text.getText().toString();
            String key1TXT = key;
            String output = cypherText;
            String key2TXT = "";
            String cipher = "Vigenere";
            String status = "E";

            Boolean checkInsertData = DB.insertData(textTXT,key1TXT, key2TXT,output,cipher,status);
            if (checkInsertData == true) {
                Toast.makeText(MainActivity3.this,"New Entry Inserted.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity3.this, "Entry Not Inserted.", Toast.LENGTH_SHORT).show();
            }

        }
    }
    public void  decryption(View v){
        String plainText = "Plain Text: ", cypherText = "", key = "";  //variables
        text = findViewById(R.id.text);
        keyword = findViewById(R.id.keyword);
        output=findViewById(R.id.output);
        DB=new DBHelper(this);
        cypherText = text.getText().toString();
        cypherText = cypherText.replaceAll("\\s", "").toUpperCase();
        key = keyword.getText().toString();
        key = key.replaceAll("\\s", "").toUpperCase();     //remove all spaces and convert the keyword to uppercase (as given in example)

        if (plainText.isEmpty() || key.isEmpty()) {
            Toast.makeText(MainActivity3.this,"Fill text boxes",Toast.LENGTH_SHORT).show();
        } else {
            for(int i=0;i<cypherText.length();i++){
                char ch=cypherText.charAt(i);             //for each character in cypher text
                char k=key.charAt(i%key.length());        //This takes each character of keyword and starts from beginning if keyword ends
                char op=65;                               //take intial character "A"
                int index=(int)k-(int)ch;                 //We know, as we go down a cloumn, the shift increaes by one. So we check the differnece between the cypher character and the key character to get the shift amount
                if(index>0){
                    index=26-index;                       //If the shift is positive, it means that we are starting from "A" again (distance from left) so we subtract the shift from 26 to get the right shift amount
                    op+=index;                            //We add shift to A to get the plain character
                    plainText+=op;                        //Add this character to plain text
                }else{
                    index=-1*index;                       //If the shift is negative, me have the correct amount so convert it to positive number
                    op+=index;                            //We add shift to A to get the plain character
                    plainText+=op;                        //Add this character to plain text
                }

            }
            output.setText(plainText);

            String textTXT = text.getText().toString();
            String key1TXT = key;
            String output = cypherText;
            String key2TXT = "";
            String cipher = "Vigenere";
            String status = "D";

            Boolean checkInsertData = DB.insertData(textTXT,key1TXT, key2TXT,output,cipher,status);
            if (checkInsertData == true) {
                Toast.makeText(MainActivity3.this,"New Entry Inserted.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity3.this, "Entry Not Inserted.", Toast.LENGTH_SHORT).show();
            }
        }

    }


}
