package com.example.cryptonite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button start;
    Button history;

    Button back;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Spinner mySpinner = (Spinner) findViewById(R.id.spin);
        start = (Button) findViewById(R.id.start);
        history = (Button) findViewById(R.id.history);
        back = (Button) findViewById(R.id.back);
        DB=new DBHelper(this);

        //ArrayAdapter<String> myAdapter = new ArrayAdapter<String> (MainActivity.this,
                //android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.names));
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item,getResources().getStringArray(R.array.names));


        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        mySpinner.setAdapter(adapter);
        mySpinner.setPrompt("Select a Cipher:");
        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                TextView textview1 = (TextView)findViewById(R.id.textView5);
                String str = String.valueOf(mySpinner.getSelectedItem());
                if(str.equals("Shift Cipher")){
                    textview1.setText("Shift cipher, also known as Caesar cipher, is one of the simplest and most widely used encryption techniques in cryptography. It works by shifting each letter of the plaintext by a fixed number of positions down the alphabet. For instance, a shift of three would turn the letter \"A\" into \"D\", \"B\" into \"E\", and so on. The resulting ciphertext can only be decrypted by someone who knows the shift value. While shift cipher is relatively easy to implement, it is also very easy to break, as there are only 25 possible shift values (assuming a standard English alphabet). As such, shift cipher is often used in combination with other encryption methods, or for educational purposes to illustrate the basic principles of cryptography.");
                }
                if(str.equals("Vigenere Cipher")){
                    textview1.setText("Vigenere cipher is a polyalphabetic substitution cipher that was first introduced by Giovan Battista Bellaso in the 16th century and later popularized by Blaise de Vigenere in the 19th century. Unlike monoalphabetic ciphers like the Caesar cipher, Vigenere cipher uses multiple alphabets to encrypt the plaintext, making it more resistant to frequency analysis attacks. The key to Vigenere cipher is a sequence of characters that determines the shift value for each letter of the plaintext. This sequence of characters is repeated cyclically for the entire length of the plaintext. Despite its improved security over monoalphabetic ciphers, Vigenere cipher can still be broken using certain cryptanalysis techniques. Nonetheless, it remains a historically significant cipher and a useful tool for demonstrating the principles of polyalphabetic substitution ciphers.");
                }
                if(str.equals("Affine Cipher")){
                    textview1.setText("Affine cipher is a type of substitution cipher that uses a mathematical function to encrypt the plaintext. The encryption function combines two parameters - a multiplicative factor and an additive factor - to generate the ciphertext. The multiplicative factor must be coprime with the length of the alphabet used, while the additive factor can be any integer. The resulting ciphertext can only be decrypted by someone who knows the values of the two parameters. Affine cipher is a simple and effective method of encryption that can be used for basic confidentiality purposes. However, it is not as secure as more complex encryption methods, and can be broken using various cryptanalysis techniques. Despite its limitations, Affine cipher remains an important historical cipher and an interesting example of the use of mathematical functions in cryptography.");
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.exit(0);
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = String.valueOf(mySpinner.getSelectedItem());
                if (str.equals("Shift Cipher")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    //intent.putExtra(DBHelper, DB);
                    startActivity(intent);
                }
                if (str.equals("Vigenere Cipher")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity3.class);
                    startActivity(intent);
                }
                if (str.equals("Affine Cipher")) {
                    Intent intent = new Intent(MainActivity.this, MainActivity4.class);
                    startActivity(intent);
                }
            }
        });

        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor res = DB.getData();
                if (res.getCount()==0) {
                    Toast.makeText(MainActivity.this, "No Entry Exists.", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()) {
                    buffer.append("Date/Time: "+res.getString(0)+"\n");
                    buffer.append("Text: "+res.getString(1)+"\n");
                    buffer.append("Key1: "+res.getString(2)+"\n");
                    buffer.append("Key2 (if any): "+res.getString(3)+"\n");
                    buffer.append("Output: "+res.getString(4)+"\n");
                    buffer.append("Cipher: "+res.getString(5)+"\n");
                    buffer.append("E/D: "+res.getString(6)+"\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("Your Cipher History");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });
    }
}