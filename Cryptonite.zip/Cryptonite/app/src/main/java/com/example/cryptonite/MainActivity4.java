package com.example.cryptonite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
    EditText text, A,B;
    TextView output;
    Button encrypt, decrypt;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

    }
    public void exit(View v) {
        System.exit(0);
    }
    public void encryption(View v) {
        String plainText = "", cypherText = "Cipher Text: ";  //variables

        text = findViewById(R.id.text);
        A = findViewById(R.id.a);
        B = findViewById(R.id.b);
        output=findViewById(R.id.output);
        DB=new DBHelper(this);
        plainText = text.getText().toString().toLowerCase();
        int a=Integer.parseInt(A.getText().toString());
        int b=Integer.parseInt(B.getText().toString());


        if (plainText.isEmpty() || String.valueOf(a).isEmpty()|| String.valueOf(b).isEmpty()) {
            Toast.makeText(MainActivity4.this,"Fill text boxes",Toast.LENGTH_SHORT).show();
        } else {
            for (char c : plainText.toCharArray()) {
                if (Character.isLetter(c)) {
                    int x = c - 'a';
                    x = (a * x + b) % 26;
                    cypherText += (char) (x + 'a');
                } else {
                    cypherText += c;
                }
            }
            output.setText(cypherText);

            String textTXT = text.getText().toString();
            String key1TXT = String.valueOf(a);
            String output = cypherText;
            String key2TXT = String.valueOf(b);
            String cipher = "Affine";
            String status = "E";

            Boolean checkInsertData = DB.insertData(textTXT,key1TXT, key2TXT,output,cipher,status);
            if (checkInsertData == true) {
                Toast.makeText(MainActivity4.this,"New Entry Inserted.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity4.this, "Entry Not Inserted.", Toast.LENGTH_SHORT).show();
            }

        }
    }
    public void  decryption(View v){
        String plainText = "Plain Text: ", cypherText = "";  //variables
        text = findViewById(R.id.text);
        A = findViewById(R.id.a);
        B = findViewById(R.id.b);
        cypherText=text.getText().toString().toLowerCase();
        output=findViewById(R.id.output);
        DB=new DBHelper(this);
        int a=Integer.parseInt(A.getText().toString());
        int b=Integer.parseInt(B.getText().toString());

        if (plainText.isEmpty() || String.valueOf(a).isEmpty()|| String.valueOf(b).isEmpty()) {
            Toast.makeText(MainActivity4.this,"Fill text boxes",Toast.LENGTH_SHORT).show();
        } else {
            int aInvMod26 = 0;
            for (int i = 0; i < 26; i++) {
                if ((a * i) % 26 == 1) {
                    aInvMod26 = i;
                    break;
                }
            }
            for (char c : cypherText.toCharArray()) {
                if (Character.isLetter(c)) {
                    int x = c - 'a';
                    x = (aInvMod26 * (x - b + 26)) % 26;
                    plainText += (char) (x + 'a');
                } else {
                    plainText += c;
                }
            }
            output.setText(plainText);

            String textTXT = text.getText().toString();
            String key1TXT = String.valueOf(a);
            String output = cypherText;
            String key2TXT = String.valueOf(b);
            String cipher = "Affine";
            String status = "D";

            Boolean checkInsertData = DB.insertData(textTXT,key1TXT, key2TXT,output,cipher,status);
            if (checkInsertData == true) {
                Toast.makeText(MainActivity4.this,"New Entry Inserted.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity4.this, "Entry Not Inserted.", Toast.LENGTH_SHORT).show();
            }
        }

    }


}

