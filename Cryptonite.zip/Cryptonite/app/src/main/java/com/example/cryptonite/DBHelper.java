package com.example.cryptonite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "History.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create Table History(timestamp TIMESTAMP primary key DEFAULT CURRENT_TIMESTAMP, text TEXT, key1 TEXT, key2 TEXT, output TEXT, cipher TEXT, ED TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists History");
    }
    public Boolean insertData (String text, String key1, String key2, String output, String cipher, String ED) {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("text",text);
        contentValues.put("key1",key1);
        contentValues.put("key2",key2);
        contentValues.put("output",output);
        contentValues.put("cipher",cipher);
        contentValues.put("ED",ED);

        long result = DB.insert("History",null,contentValues);
        if (result == -1) {
            return false;
        } else return true;
    }

    public Cursor getData () {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from History",null);
        return cursor;
    }
}

