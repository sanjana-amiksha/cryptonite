package com.example.cryptonite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    EditText text, keyword;
    TextView output;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }

    public void exit(View v) {
        System.exit(0);
    }
    public void encryption(View v) {
        String plainText = "", cypherText = "Cipher Text:\n";  //variables

        text = findViewById(R.id.text);
        keyword = findViewById(R.id.keyword);
        output=findViewById(R.id.output);
        DB=new DBHelper(this);
        plainText = text.getText().toString();
        int key=Integer.parseInt(keyword.getText().toString());
        key%=26;


        if (plainText.isEmpty() || String.valueOf(key).isEmpty()) {
            Toast.makeText(MainActivity2.this,"Fill text boxes",Toast.LENGTH_SHORT).show();
        } else {
            for(int i=0;i<plainText.length();i++)
            {
                char ch=plainText.charAt(i);
                if(Character.isUpperCase(ch))
                {
                    ch+=key;
                    if(ch>90)
                        ch-=26;
                    cypherText+=ch;
                }
                else if(Character.isLowerCase(ch))
                {
                    ch+=key;
                    if(ch>122)
                        ch-=26;
                    cypherText+=ch;
                }
                else
                    cypherText+=ch;
            }
            output.setText(cypherText);



            String textTXT = text.getText().toString();
            String key1TXT = String.valueOf(key);
            String output = cypherText;
            String key2TXT = "";
            String cipher = "Shift";
            String status = "E";

            Boolean checkInsertData = DB.insertData(textTXT,key1TXT, key2TXT,output,cipher,status);
            if (checkInsertData == true) {
                Toast.makeText(MainActivity2.this,"New Entry Inserted.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity2.this, "Entry Not Inserted.", Toast.LENGTH_SHORT).show();
            }


        }
    }
    public void  decryption(View v){
        String plainText = "Plain Text:\n", cypherText = "";  //variables
        text = findViewById(R.id.text);
        keyword = findViewById(R.id.keyword);
        output=findViewById(R.id.output);
        DB=new DBHelper(this);
        cypherText = text.getText().toString();
        int key=Integer.parseInt(keyword.getText().toString());
        key%=26;

        if (plainText.isEmpty() || String.valueOf(key).isEmpty()) {
            Toast.makeText(MainActivity2.this,"Fill text boxes",Toast.LENGTH_SHORT).show();
        } else {
            for(int i=0;i<cypherText.length();i++)
            {
                char ch=cypherText.charAt(i);
                if(Character.isUpperCase(ch))
                {
                    ch-=key;
                    if(ch<65)
                        ch+=26;
                    plainText+=ch;
                }
                else if(Character.isLowerCase(ch))
                {
                    ch-=key;
                    if(ch<97)
                        ch+=26;
                    plainText+=ch;
                }
                else
                    plainText+=ch;
            }
            output.setText(plainText);


            String textTXT = cypherText;
            String key1TXT = String.valueOf(key);
            String output = plainText;
            String key2TXT = "";
            String cipher = "Shift";
            String status = "D";

            Boolean checkInsertData = DB.insertData(textTXT,key1TXT, key2TXT,output,cipher,status);
            if (checkInsertData == true) {
                Toast.makeText(MainActivity2.this,"New Entry Inserted.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity2.this, "Entry Not Inserted.", Toast.LENGTH_SHORT).show();
            }
        }

    }


}

